/*
 * File:   isr.c
 * Author: franc
 *
 * Created on 11 de marzo de 2022, 08:45 AM
 */


#include <xc.h>

void main(void) {
    return;
}
